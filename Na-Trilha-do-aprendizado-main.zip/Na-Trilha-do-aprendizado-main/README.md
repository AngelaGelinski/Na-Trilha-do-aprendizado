# Na-Trilha-do-aprendizado
 Projeto em desenvolvimento sobre o ano letivo de 2021, na materia de Desenvolvimento Web, como o professor Francis. Vamos ligar todos os trabalhos desenvolvidos na diciplina, para facilitar a visualizaçao de projetos como: Introduçao ao HTML, Imagens e Listas, Hiperlinks, e atividades extras
